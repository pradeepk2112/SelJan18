package dataReader;


public abstract class AbstractDataProvider {
	
	
}
